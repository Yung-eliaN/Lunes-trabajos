/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyect_cafetera;

/**
 *
 * @author Upar
 */
public class cafetera {
    
    String marca;
    String color;

    public cafetera(String marca, String color) {
        this.marca = marca;
        this.color = color;
    }
    
    public void prepararCafe(){
        
        System.out.println("1. calentando");
         System.out.println("2. preparando");
          System.out.println("3. listo");
    }
    
    
    
    
    
    
}
