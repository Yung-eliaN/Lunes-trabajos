/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyect_cafetera;

/**
 *
 * @author Upar
 */
public class Proyect_cafetera {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        cafetera micafetera = new cafetera("oster", "roja");
        
        micafetera.prepararCafe();
        
        
        

    }
    
}
