/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package futboll;

/**
 *
 * @author Upar
 */
public class futbolista {
    
    
    private int id;
    private String nombre;
    private String apellidos;
    private int edad;
    private int dorsal;
    private String demarcacion;
    
    
    
}
