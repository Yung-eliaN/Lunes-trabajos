/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package futboll;

/**
 *
 * @author Upar
 */
public class seleccion {
 
    protected int id;
    protected String nombre;
    protected String apellidos;
    protected int edad;   
    
    
    
public seleccion(){
        
}


    public seleccion(int id, String nombre, String apellidos, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
    }
 
    
/**
 *
 * ID get, set
 */
public int getid(){
return id;
}


public void setid(int id){
    this.id = id;
}


/**
 *
 * Nombre get, set
 */
public String getnombre(){
return nombre;
}

public void setnombre(String nombre){
    this.nombre = nombre;
}
 

/**
 *
 * Apellido get , set
 * 
 */    
    

public String getapellidos(){
return apellidos;
}

public void setapellidos(String apellidos){
    this.apellidos = apellidos;
}


    
/**
 *
 * Edad get, set
 */    

public int getedad(){
return edad;
}

public void setedad(int edad){
    this.edad = edad;
}



}
