/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mascomain;

/**
 *
 * @author Upar
 */
public class mascotas {
    
   private String nombre;
   private String especie;
   private int edad;

   public String getnombre(){
        return nombre;
    }

   public String getespecie(){
        return especie;
    }   
 
    public int getedad(){
        return edad;
    }
   
    
    
    public void setnombre(String nuevoNombre){

      this.nombre = nuevoNombre;

    }
    
    public void setespecie(String nuevaEspecie){

      this.nombre = nuevaEspecie;

    }
   
    
    public void setedad(int nuevaEdad){
        if (nuevaEdad >0){
            this.edad = nuevaEdad;
        }
        
        else {
            System.out.println("el numero no puede ser negativo");
        }
    }
    
}
