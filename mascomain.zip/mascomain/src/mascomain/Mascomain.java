/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mascomain;

/**
 *
 * @author Upar
 */
public class Mascomain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
               mascotas persona1 = new mascotas();
                
          
           persona1.setnombre("lauter");
           
           System.out.println("el nombre de la mascota es: " + persona1.getnombre());
           
           persona1.setnombre("lauter");
           
           
           
           persona1.setnombre("Perra");
           
           System.out.println("la espeie es: " + persona1.getnombre());
           
           persona1.setnombre("Perra");
               
               
               
           persona1.setedad(15);
           
           System.out.println("la edad es: " + persona1.getedad());
           
           persona1.setedad(15);
           

    }   
        
        
        
    }
    
