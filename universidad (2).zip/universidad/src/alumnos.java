/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Upar
 */
public class alumnos {
    
   String Nombre;
   String Carrera;
   int Grupo;
   String Semestre;
   double Promedio;
   
   
public alumnos(){
    
}

    public alumnos(String Nombre, String Carrera, int Grupo, String Semestre, double Promedio) {
        this.Nombre = Nombre;
        this.Carrera = Carrera;
        this.Grupo = Grupo;
        this.Semestre = Semestre;
        this.Promedio = Promedio;
    }
 
   

public String getNombre(){   
    
    return Nombre; 
}

public void setNombre( String Nombre){
    this.Nombre = Nombre;
}




public String getCarrera(){       
    return Carrera; 
}

public void setCarrera( String Carrera){
    this.Carrera = Carrera;
}






public int getGrupo(){   
    
    return Grupo; 
}

public void setGrupo( int Grupo){
    this.Grupo = Grupo;
}




public String getSemestre(){   
    
    return Semestre; 
}

public void setSemestre( String Semestre){
    this.Semestre = Semestre;
}





public double getPromedio(){   
    
    return Promedio; 
}

public void setPromedio( double Promedio){
    this.Promedio = Promedio;
}




}




    
       


    
