/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cocacola;
import java.util.Scanner;

/**
 *
 * @author Upar
 */
public class Cocacola {

    
    
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner (System.in);
        
        
        String nombre = "";
        int antiguedad = 0;
        int clave = 0;
        
        
        System.out.println("*---------------------------------------*");
        System.out.println("*Bienvenido al sistema vacacional CocaCola*");
        System.out.println("*---------------------------------------*");
        System.out.println("");
        System.out.println("");
        
        
          System.out.println("Digite el Nombre del empleado");
          nombre = entrada.nextLine();
          System.out.println("Digite la antiguedad del empelado");
          antiguedad = entrada.nextInt();
          System.out.println("Digite la clave del empleado");
          clave = entrada.nextInt();
          
          
            if (clave == 1){
                
               if(antiguedad == 1){
             System.out.println("El trabajador " + nombre + " tiene derecho a 6 dias de vacaciones");
         }     else if ( antiguedad >= 2 && antiguedad <= 6){
             System.out.println("El trabajador " + nombre + " tiene derecho a 14 dias de vacaciones");
         }     else if ( antiguedad >= 7){
             System.out.println("El trabajador " + nombre + " tiene derecho a 20 dias de vacaciones");
         }     else {
             System.out.println("El trabajador no tiene derechos vacacionales, hasta el momento");
         }
                                            
            }
            
            if (clave == 2){
                
                if(antiguedad == 1){
             System.out.println("El trabajador " + nombre + " tiene derecho a 7 dias de vacaciones");
         }   else if ( antiguedad >= 2 && antiguedad <= 6){
             System.out.println("El trabajador " + nombre + " tiene derecho a 15 dias de vacaciones");
         }   else if ( antiguedad >= 7){
             System.out.println("El trabajador " + nombre + " tiene derecho a 22 dias de vacaciones");
         }   else {
             System.out.println("El trabajador no tiene derechos vacacionales, hasta el momento");
         }
                              
                
            }
            
            
            if (clave == 3){
                
                if(antiguedad == 1){
             System.out.println("El trabajador " + nombre + " tiene derecho a 10 dias de vacaciones");
         }   else if ( antiguedad >= 2 && antiguedad <= 6){
             System.out.println("El trabajador " + nombre + " tiene derecho a 20 dias de vacaciones");
         }   else if ( antiguedad >= 7){
             System.out.println("El trabajador " + nombre + " tiene derecho a 30 dias de vacaciones");
         }   else {
             System.out.println("El trabajador no tiene derechos vacacionales, hasta el momento");
         }
                              
                
            }
            
            
            else {
                System.out.println("la clave es inexistente");
            }

    }
    
}
